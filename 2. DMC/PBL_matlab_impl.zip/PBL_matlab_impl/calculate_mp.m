function [Mp] = calculate_mp(srm, N, N1)
    km = srm(end);
    D = length(srm);
    
    ones(length(srm), 1) * km;
    
    srm = [srm, ones(1, length(srm)) * km];
    
  for i = 1:D-1
         Mp(:,i) = srm(N1+i:N+i) - srm(i);
  end
end