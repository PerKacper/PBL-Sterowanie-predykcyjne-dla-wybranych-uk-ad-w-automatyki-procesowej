%% Calculations

% M = calculate_m([0 0  0.2 0.5 0.6 0.62], 6, 3, 3)
% 
% K = calculate_k(M, 0.1)
% 
% Mp = calculate_mp([0 0  0.2 0.5 0.6 0.62], 6, 3)
% 
% du = calculate_du([0 0  0.2 0.5 0.6 0.62], 6, 3, K, Mp, 3, 2, ones(1:6), 3)


%% Another book example

SRM = [0 0 0.271 0.489 0.687 0.845 0.977 1.087 1.179 1.256...
    1.320 1.374 1.419 1.456 1.487 1.513 1.535 1.553 1.565 1.581...
    1.592 1.6 1.608 1.614 1.619 1.623 1.627 1.63 1.633 1.635]

M = calculate_m(SRM, 10, 5, 3)

K = calculate_k(M, 1)

Mp = calculate_mp(SRM, 10, 3)

du = calculate_du(SRM, 10, 3, K, Mp, 1, 0, ones(1:6), 1)

