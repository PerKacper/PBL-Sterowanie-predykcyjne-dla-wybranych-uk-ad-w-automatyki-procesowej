function [K] = calculate_k(M, lambda)
    [~, cols] = size(M);
    K = inv(M' * M + lambda * eye(cols)) * M';
end