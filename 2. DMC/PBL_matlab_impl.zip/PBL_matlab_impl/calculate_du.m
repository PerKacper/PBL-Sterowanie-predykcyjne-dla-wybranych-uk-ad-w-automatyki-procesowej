function [du] = calculate_du(srm, N, N1, K, Mp, y_zad, y, past_du, k)
    D = length(srm)
    
    ke = 0;
    for p=N1:N
       ke = ke + K(1, p-N1+1)
    end
    
    e = y_zad - y
    
    
    % Forced
    K(1,:)
    ku = K(1,:) * Mp

    forced_response = 0
    for j=1:D-1
        if(k - j > 0)
            forced_response = forced_response + (past_du(k - j) * ku(j))
        end
    end
    
    du = ke * e - forced_response;
end