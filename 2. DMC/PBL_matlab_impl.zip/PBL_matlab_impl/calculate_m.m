function [M] = calculate_m(srm, N, Nu, N1)
    row1 = [fliplr(srm(1:N1)), zeros(1, N - Nu - length(srm(1:N1)))];
    col1 = srm(N1:N);
    
    M = toeplitz(col1, row1);
end

