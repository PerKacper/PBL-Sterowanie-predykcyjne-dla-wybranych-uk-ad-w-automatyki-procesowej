import numpy as np
from scipy.linalg import toeplitz

# Piotr Tatjewski book based implementation, page > 116


def M(SRM, N, Nu, N1):
    col = SRM[N1:N]

    row = np.zeros(N - Nu)
    row[0:N1] = SRM[N1:0:-1]

    return toeplitz(col, row)


def Mp(SRM, N, N1):
    km = SRM[-1]
    D = len(SRM)

    SRM = np.append(SRM, [km] * D)

    Mp = np.zeros((N-N1, D-1), dtype=float)
    for i in range(D-1):
        Mp[:, i] = SRM[N1+i+1:N+i+1] - SRM[i]

    return Mp


def K(M, lmbd):
    """
    Args:
        M (np.ndarray): M matrix
        lmbd (float): Lambda value
    """
    return np.linalg.inv(np.transpose(M) @ M + lmbd *
                         np.eye(M.shape[1])) @ np.transpose(M)


def du(SRM, N, N1, K, Mp, y_zad, y, past_du, k):
    D = len(SRM)

    ke = 0
    for p in range(N1, N):
        ke += K[0, p-N1]

    ku = K[0, :] @ Mp

    forced_response = 0
    for j in range(D-2):
        if k - j > -1:
            forced_response = forced_response + (past_du[k - j] * ku[j])

    e = y_zad - y
    return ke * e - forced_response


if __name__ == '__main__':
    # Quick tests according to the book example

    SRM = np.array([0, 0, 0.2, 0.5, 0.6, 0.62])
    N = 6
    Nu = 3
    N1 = 2

    print(Mp(SRM, N, N1))
    print(M(SRM, N, Nu, N1))

    M = M(SRM, N, Nu, N1)
    print(K(M, 0.01))

    Mp = Mp(SRM, N, N1)
    K = K(M, 0.01)
    print(du(SRM, N, N1, K, Mp, 3, 2, np.zeros(6), 0))
