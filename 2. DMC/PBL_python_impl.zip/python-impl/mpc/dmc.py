from .impl import calc

# Piotr Tatjewski book based implementation


class DMC:
    def __init__(self):
        self.SRM = None
        self.R = 25

        self.N = 300
        self.N1 = 10
        self.Nu = 120
        self.lmbd = 9

    def init(self):
        self.SRM = self.__load()
        self.D = len(self.SRM)
        self.pasts_du = []

        self.M = calc.M(self.SRM, self.N, self.Nu, self.N1)
        self.Mp = calc.Mp(self.SRM, self.N, self.N1)
        self.K = calc.K(self.M, self.lmbd)

    def update(self, R):
        self.R = R

    def predict(self, y, u):
        """Make a prediction according to internal state

        Returns:
            float: du - increase of control signal
        """
        du = calc.du(self.SRM, self.N, self.N1, self.K, self.Mp,
                     self.R, y, self.pasts_du, len(self.pasts_du) - 1)

        # Borders
        if u - du > 15 or u - du < 1:
            du = 0

        if du > 0.5:
            du = 0.5
        elif du < -0.5:
            du = -0.5

        self.pasts_du.append(du)

        return du

    def __load(self):
        data = []

        with open('srm.txt') as file:
            for line in file:
                data.append(float(line.strip()))

        return data
