#!/usr/bin/env python3

from devices import s7
from managers.controll_manager import ControllManager
from mpc.dmc import DMC


def production():
    dmc = DMC()
    plc = s7.PLC(s7.Client(), s7.CommunicationParameters('192.168.0.6', 0, 1))

    manager = ControllManager(dmc, plc)
    manager.run()


if __name__ == '__main__':
    production()
