import logging

from snap7 import client
from snap7 import util


LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.DEBUG)


# FIXME's:
# * Remove class/functions hardcode globals
# * Add parsing according to Oskar's DB's
# * Oskar's new DB is fucked. Lack of bit indicating which
#   kind of system controller is being used.

# Utils
class CommunicationParameters:
    def __init__(self, address, rack, slot):
        self.ip = address
        self.rack = rack
        self.slot = slot


class Client(client.Client):
    def __init__(self):
        super().__init__('/usr/lib/libsnap7.so')


# Domain
class PLC:
    LIVE_BIT_ADDRESS = 30
    DB_NUMBER = 8
    DB_SIZE = 32

    def __init__(self, client, com_params):
        self.client = client
        self.com_params = com_params

    def init(self):
        self.client.connect(self.com_params.ip, self.com_params.rack,
                            self.com_params.slot)
        LOGGER.info('PLC successfully initialized')

    def read(self):
        LOGGER.debug('Reading from PLC')

        data = self.client.db_read(self.DB_NUMBER, 0, self.DB_SIZE)

        data_map = dict()
        data_map['R'] = util.get_real(data, 0)
        data_map['u'] = util.get_real(data, 8)
        data_map['y'] = util.get_real(data, 14)
        data_map['counter'] = util.get_int(data, 22)

        return data_map

    def write(self, data):
        LOGGER.debug('Writting to PLC')

        buffer = bytearray(8)
        util.set_int(buffer, 4, int(data['counter']))
        util.set_real(buffer, 0, float(data['u']))

        # Live bit
        util.set_bool(buffer, 6, 0, False)

        self.client.db_write(self.DB_NUMBER, 24, buffer)


# Debug
def ping_tl(com_params):
    dev = Client()
    dev.connect(com_params.ip, com_params.rack, com_params.slot)

    if dev.get_connected():
        print('Pinged device is available')
    else:
        print('Pinged device didn\'t respond')


def ping_domain(com_params):
    LIVE_BIT_ADDRESS = 28
    DB_NUMBER = 8

    dev = Client()
    dev.connect(com_params.ip, com_params.rack, com_params.slot)

    # Setting diagnostical 0 to live-bit
    buffer = bytearray([0b00000000])
    util.set_bool(buffer, 0, 0, False)
    dev.db_write(DB_NUMBER, LIVE_BIT_ADDRESS, buffer)

    LOGGER.info('Domain ping send')
