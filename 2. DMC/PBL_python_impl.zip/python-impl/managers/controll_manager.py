import time


class ControllManager:
    def __init__(self, controller, io):
        self.controller = controller
        self.io = io

        self.die = False

    def kill(self):
        self.die = True

    def run(self):
        # Initialization
        self.controller.init()
        self.io.init()

        while not self.die:
            rules = self.io.read()

            self._Y.append(rules['y'])

            self.controller.update(rules['R'])
            du = self.controller.predict(rules['y'], rules['u'])

            results = dict()
            results['u'] = rules['u'] - du
            results['counter'] = rules['counter']

            self.io.write(results)

            time.sleep(0.1)
